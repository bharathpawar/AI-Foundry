/*
Hybrid Private Resources Setup for Azure AI Foundry Agents
-----------------------------------------------------------
This template creates an Azure AI Foundry account with public network access DISABLED,
while keeping backend resources (AI Search, Cosmos DB, Storage) on private endpoints.

Key differences from template 15 (fully private):
- AI Services: publicNetworkAccess = Disabled (default)
- Backend resources: Still private (AI Search, Cosmos DB, Storage)
- Data Proxy: networkInjections configured to route to private VNet

This enables:
✓ Agents can use AI Search tool (routed via Data Proxy to private endpoint)
✓ Agents can use MCP servers running on the VNet

Architecture:
  Private VNet → AI Services (private) → Data Proxy → Private VNet → Backend Resources
*/
@description('Location for all resources.')
@allowed([
  'westus'
  'westus2'
  'eastus'
  'eastus2'
  'japaneast'
  'francecentral'
  'spaincentral'
  'uaenorth'
  'southcentralus'
  'italynorth'
  'germanywestcentral'
  'brazilsouth'
  'southafricanorth'
  'australiaeast'
  'swedencentral'
  'canadaeast'
  'canadacentral'
  'westeurope'
  'westus3'
  'uksouth'
  'southindia'

  //only class B and C
  'koreacentral'
  'polandcentral'
  'switzerlandnorth'
  'norwayeast'
])
param location string = 'eastus2'

@description('Name prefix for your AI Services (Cognitive Services) resource. Lowercase alphanumeric only; a 4-character random suffix will be appended.')
@minLength(2)
@maxLength(40)
param aiServices string = 'aifoundry'

// Model deployment parameters
@description('The name of the model you want to deploy')
param modelName string = 'gpt-4o-mini'
@description('The provider of your model')
param modelFormat string = 'OpenAI'
@description('The version of your model')
param modelVersion string = '2024-07-18'
@description('The sku of your model deployment')
param modelSkuName string = 'GlobalStandard'
@description('The tokens per minute (TPM) of your model deployment')
param modelCapacity int = 30

// Create a short, unique suffix, that will be unique to each resource group
// Deterministic suffix for idempotent re-deploys (same RG = same names)
var uniqueSuffix = substring(uniqueString(resourceGroup().id), 0, 4)
var accountName = toLower('${aiServices}${uniqueSuffix}')

@description('Name prefix for your Foundry project. A 4-character random suffix will be appended.')
@minLength(2)
@maxLength(40)
param firstProjectName string = 'project'

@description('This project will be a sub-resource of your account')
param projectDescription string = 'A project for the AI Foundry account with network secured deployed Agent'

@description('The display name of the project')
param displayName string = 'network secured agent project'

// Existing Virtual Network parameters
@description('Virtual Network name. When `existingVnetResourceId` is set, this is ignored — the name is derived from the resource ID.')
param vnetName string = 'agent-vnet'

@description('Agent subnet name. Ignored when `existingAgentSubnetResourceId` is set.')
param agentSubnetName string = 'agent-subnet'

@description('Private endpoint subnet name. Ignored when `existingPeSubnetResourceId` is set.')
param peSubnetName string = 'pe-subnet'

@description('MCP subnet name (hosts user-deployed Container Apps such as MCP servers). Ignored when `existingMcpSubnetResourceId` is set.')
param mcpSubnetName string = 'mcp-subnet'

//Existing standard Agent required resources
@description('Existing Virtual Network name Resource ID')
param existingVnetResourceId string = ''

@description('Address space for the VNet (only used for new VNet)')
param vnetAddressPrefix string = ''

@description('Address prefix for the agent subnet. The default value is 192.168.0.0/24 but you can choose any size /26 or any class like 10.0.0.0 or 172.168.0.0')
param agentSubnetPrefix string = ''

@description('Address prefix for the private endpoint subnet')
param peSubnetPrefix string = ''

@description('Address prefix for the MCP subnet. The default value is 192.168.2.0/24.')
param mcpSubnetPrefix string = ''

@description('Optional ARM Resource ID of an existing agent subnet. If provided, the subnet will be referenced as-is and will not be created/modified.')
param existingAgentSubnetResourceId string = ''

@description('Optional ARM Resource ID of an existing private endpoint subnet. If provided, the subnet will be referenced as-is and will not be created/modified.')
param existingPeSubnetResourceId string = ''

@description('Optional ARM Resource ID of an existing MCP subnet. If provided, the subnet will be referenced as-is and will not be created/modified.')
param existingMcpSubnetResourceId string = ''

@description('The AI Search Service full ARM Resource ID. Optional — leave empty to create a new one.')
param existingAiSearchResourceId string = ''
@description('The AI Storage Account full ARM Resource ID. Optional — leave empty to create a new one.')
param existingAzureStorageAccountResourceId string = ''
@description('The Cosmos DB Account full ARM Resource ID. Optional — leave empty to create a new one.')
param existingAzureCosmosDBAccountResourceId string = ''

@description('The Microsoft Fabric Workspace full ARM Resource ID. Optional — enables Fabric private link connectivity.')
param existingFabricWorkspaceResourceId string = ''

@description('Enable Azure Container Registry with Private Endpoint. When true, creates an ACR (Premium SKU) with a PE in the private endpoints subnet.')
param enableContainerRegistry bool = true

@description('Optional developer IP CIDR to allowlist for ACR push access (e.g., 203.0.113.0/26 or 10.0.0.0/16). When empty, public access remains disabled.')
param developerIpCidr string = ''

//New Param for resource group of Private DNS zones
//@description('Optional: Resource group containing existing private DNS zones. If specified, DNS zones will not be created.')
//param existingDnsZonesResourceGroup string = ''

@description('Map of private DNS zone FQDNs to an object `{ subscriptionId, resourceGroup }` describing where the zone lives. Empty `resourceGroup` means "create the zone in this deployment\'s resource group". A non-empty `resourceGroup` references an existing zone in that RG; empty `subscriptionId` defaults to the current subscription, otherwise the zone is referenced cross-subscription. Note: when referencing an existing zone, the VNet link to that zone is NOT managed by this template — the caller must ensure the zone is already linked to the target VNet.')
param existingDnsZones object = {
  'privatelink.services.ai.azure.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.openai.azure.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.cognitiveservices.azure.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.search.windows.net': { subscriptionId: '', resourceGroup: '' }
  'privatelink.blob.${environment().suffixes.storage}': { subscriptionId: '', resourceGroup: '' }
  'privatelink.documents.azure.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.fabric.microsoft.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.azurecr.io': { subscriptionId: '', resourceGroup: '' }
}

@description('Object mapping Azure Monitor private DNS zone names to an existing zone subscription/resource group, or empty strings to create it. Use to bring your own centralized Private DNS Zones (e.g. an Azure Landing Zone) for agent tracing.')
param existingMonitorDnsZones object = {
  'privatelink.monitor.azure.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.oms.opinsights.azure.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.ods.opinsights.azure.com': { subscriptionId: '', resourceGroup: '' }
  'privatelink.agentsvc.azure-automation.net': { subscriptionId: '', resourceGroup: '' }
}

var projectName = toLower('${firstProjectName}${uniqueSuffix}')
var cosmosDBName = toLower('${aiServices}${uniqueSuffix}cosmosdb')
var aiSearchName = toLower('${aiServices}${uniqueSuffix}search')
var azureStorageName = toLower('${aiServices}${uniqueSuffix}storage')
var acrName = toLower('acr${uniqueSuffix}')

// Check if existing resources have been passed in
var storagePassedIn = existingAzureStorageAccountResourceId != ''
var searchPassedIn = existingAiSearchResourceId != ''
var cosmosPassedIn = existingAzureCosmosDBAccountResourceId != ''
var existingVnetPassedIn = existingVnetResourceId != ''

// Existing-subnet flags. When a subnet ARM ID is provided we derive the subnet name
// from the ID itself so we look up the right subnet (instead of trusting the *SubnetName param).
var agentSubnetExists = existingAgentSubnetResourceId != ''
var peSubnetExists    = existingPeSubnetResourceId    != ''
var mcpSubnetExists   = existingMcpSubnetResourceId   != ''
var effectiveAgentSubnetName = agentSubnetExists ? last(split(existingAgentSubnetResourceId, '/')) : agentSubnetName
var effectivePeSubnetName    = peSubnetExists    ? last(split(existingPeSubnetResourceId, '/'))    : peSubnetName
var effectiveMcpSubnetName   = mcpSubnetExists   ? last(split(existingMcpSubnetResourceId, '/'))   : mcpSubnetName

var acsParts = split(existingAiSearchResourceId, '/')
var aiSearchServiceSubscriptionId = searchPassedIn ? acsParts[2] : subscription().subscriptionId
var aiSearchServiceResourceGroupName = searchPassedIn ? acsParts[4] : resourceGroup().name

var cosmosParts = split(existingAzureCosmosDBAccountResourceId, '/')
var cosmosDBSubscriptionId = cosmosPassedIn ? cosmosParts[2] : subscription().subscriptionId
var cosmosDBResourceGroupName = cosmosPassedIn ? cosmosParts[4] : resourceGroup().name

var storageParts = split(existingAzureStorageAccountResourceId, '/')
var azureStorageSubscriptionId = storagePassedIn ? storageParts[2] : subscription().subscriptionId
var azureStorageResourceGroupName = storagePassedIn ? storageParts[4] : resourceGroup().name

var vnetParts = split(existingVnetResourceId, '/')
var vnetSubscriptionId = existingVnetPassedIn ? vnetParts[2] : subscription().subscriptionId
var vnetResourceGroupName = existingVnetPassedIn ? vnetParts[4] : resourceGroup().name
var existingVnetName = existingVnetPassedIn ? last(vnetParts) : vnetName
var trimVnetName = trim(existingVnetName)

@description('The name of the project capability host to be created')
param projectCapHost string = 'caphostproj'

// Create Virtual Network and Subnets
module vnet 'modules-network-secured/network-agent-vnet.bicep' = {
  name: 'vnet-${trimVnetName}-${uniqueSuffix}-deployment'
  params: {
    location: location
    vnetName: trimVnetName
    useExistingVnet: existingVnetPassedIn
    existingVnetResourceGroupName: vnetResourceGroupName
    agentSubnetName: effectiveAgentSubnetName
    peSubnetName: effectivePeSubnetName
    mcpSubnetName: effectiveMcpSubnetName
    vnetAddressPrefix: vnetAddressPrefix
    agentSubnetPrefix: agentSubnetPrefix
    peSubnetPrefix: peSubnetPrefix
    mcpSubnetPrefix: mcpSubnetPrefix
    existingVnetSubscriptionId: vnetSubscriptionId
    agentSubnetExists: agentSubnetExists
    peSubnetExists: peSubnetExists
    mcpSubnetExists: mcpSubnetExists
  }
}

/*
  Create the AI Services account and gpt-4o model deployment
*/
module aiAccount 'modules-network-secured/ai-account-identity.bicep' = {
  name: '${accountName}-${uniqueSuffix}-deployment'
  params: {
    // workspace organization
    accountName: accountName
    location: location
    modelName: modelName
    modelFormat: modelFormat
    modelVersion: modelVersion
    modelSkuName: modelSkuName
    modelCapacity: modelCapacity
    agentSubnetId: vnet.outputs.agentSubnetId
  }
}
/*
  Inline existence checks (replaces the previous validate-existing-resources.bicep module,
  which was tautological: it set `*Exists = passedIn && (resource.name == parts[8])` where
  `parts[8]` was the very same string used to reference the resource by name).
  An empty resource ID means "create new".
*/
var aiSearchExists = existingAiSearchResourceId != ''
var azureStorageExists = existingAzureStorageAccountResourceId != ''
var cosmosDBExists = existingAzureCosmosDBAccountResourceId != ''

// This module will create new agent dependent resources
// A Cosmos DB account, an AI Search Service, and a Storage Account are created if they do not already exist
module aiDependencies 'modules-network-secured/standard-dependent-resources.bicep' = {
  name: 'dependencies-${uniqueSuffix}-deployment'
  params: {
    location: location
    azureStorageName: azureStorageName
    aiSearchName: aiSearchName
    cosmosDBName: cosmosDBName

    // AI Search Service parameters
    existingAiSearchResourceId: existingAiSearchResourceId
    aiSearchExists: aiSearchExists

    // Storage Account
    existingAzureStorageAccountResourceId: existingAzureStorageAccountResourceId
    azureStorageExists: azureStorageExists

    // Cosmos DB Account
    existingCosmosDBResourceId: existingAzureCosmosDBAccountResourceId
    cosmosDBExists: cosmosDBExists
  }
}

// Note: previously this file declared `existing` references to storage / aiSearch / cosmosDB
// solely to use them in module `dependsOn` blocks. That pattern is a no-op (dependsOn on
// `existing` resources is silently ignored), so they were removed. The real dependency on
// these resources flows implicitly through `aiDependencies.outputs.*` references in params.

// Private Endpoint and DNS Configuration
// This module sets up private network access for all Azure services:
// 1. Creates private endpoints in the specified subnet
// 2. Sets up private DNS zones for each service
// 3. Links private DNS zones to the VNet for name resolution
// 4. Configures network policies to restrict access to private endpoints only
module privateEndpointAndDNS 'modules-network-secured/private-endpoint-and-dns.bicep' = {
  name: '${uniqueSuffix}-private-endpoint'
  params: {
    aiAccountName: aiAccount.outputs.accountName // AI Services to secure
    aiSearchName: aiDependencies.outputs.aiSearchName // AI Search to secure
    storageName: aiDependencies.outputs.azureStorageName // Storage to secure
    cosmosDBName: aiDependencies.outputs.cosmosDBName
    fabricWorkspaceResourceId: existingFabricWorkspaceResourceId // Microsoft Fabric workspace (optional)
    vnetName: vnet.outputs.virtualNetworkName // VNet containing subnets
    peSubnetName: vnet.outputs.peSubnetName // Subnet for private endpoints
    suffix: uniqueSuffix // Unique identifier
    vnetResourceGroupName: vnet.outputs.virtualNetworkResourceGroup
    vnetSubscriptionId: vnet.outputs.virtualNetworkSubscriptionId // Subscription ID for the VNet
    cosmosDBSubscriptionId: cosmosDBSubscriptionId // Subscription ID for Cosmos DB
    cosmosDBResourceGroupName: cosmosDBResourceGroupName // Resource Group for Cosmos DB
    aiSearchSubscriptionId: aiSearchServiceSubscriptionId // Subscription ID for AI Search Service
    aiSearchResourceGroupName: aiSearchServiceResourceGroupName // Resource Group for AI Search Service
    storageAccountResourceGroupName: azureStorageResourceGroupName // Resource Group for Storage Account
    storageAccountSubscriptionId: azureStorageSubscriptionId // Subscription ID for Storage Account
    existingDnsZones: existingDnsZones
  }
  // Dependencies on `aiDependencies` and `vnet` are implicit through param references
  // (e.g. aiAccount.outputs, aiDependencies.outputs.*, vnet.outputs.*).
}

// Optional: Azure Container Registry with Private Endpoint
module acr 'modules-network-secured/container-registry.bicep' = if (enableContainerRegistry) {
  name: 'acr-${uniqueSuffix}-deployment'
  params: {
    acrName: acrName
    location: location
    peSubnetId: vnet.outputs.peSubnetId
    vnetId: vnet.outputs.virtualNetworkId
    suffix: uniqueSuffix
    // The central private-endpoint-and-dns module already creates privatelink.azurecr.io and
    // links it to the VNet (azurecr is in existingDnsZones). Point the ACR module at that existing
    // zone so it references it instead of creating a second (conflicting) VNet link.
    existingDnsZoneResourceGroup: empty(existingDnsZones['privatelink.azurecr.io'].resourceGroup) ? resourceGroup().name : existingDnsZones['privatelink.azurecr.io'].resourceGroup
    dnsZonesSubscriptionId: empty(existingDnsZones['privatelink.azurecr.io'].subscriptionId) ? subscription().subscriptionId : existingDnsZones['privatelink.azurecr.io'].subscriptionId
    developerIpCidr: developerIpCidr
    projectPrincipalId: aiProject.outputs.projectPrincipalId
  }
  dependsOn: [
    privateEndpointAndDNS
  ]
}

// Application Insights for hosted-agent tracing (this template ships none). Creates a
// workspace-based Application Insights and connects it to the account so the agent exports traces.
module applicationInsights 'modules-network-secured/application-insights.bicep' = {
  name: 'app-insights-${uniqueSuffix}-deployment'
  params: {
    location: location
    suffix: uniqueSuffix
    aiAccountName: aiAccount.outputs.accountName
    disablePublicIngestion: true
  }
}

// Private trace ingestion path (Azure Monitor Private Link Scope) so an in-VNet agent's traces
// reach Application Insights over the private link rather than the (disabled) public endpoint.
module monitorPrivateLink 'modules-network-secured/monitor-private-link-scope.bicep' = {
  name: 'monitor-pls-${uniqueSuffix}-deployment'
  params: {
    location: location
    suffix: uniqueSuffix
    appInsightsId: applicationInsights.outputs.appInsightsId
    logAnalyticsId: applicationInsights.outputs.logAnalyticsId
    vnetId: vnet.outputs.virtualNetworkId
    peSubnetId: vnet.outputs.peSubnetId
    existingDnsZones: existingMonitorDnsZones
  }
  dependsOn: [
    privateEndpointAndDNS
  ]
}

/*
  Creates a new project (sub-resource of the AI Services account)
*/
module aiProject 'modules-network-secured/ai-project-identity.bicep' = {
  name: '${projectName}-${uniqueSuffix}-deployment'
  params: {
    // workspace organization
    projectName: projectName
    projectDescription: projectDescription
    displayName: displayName
    location: location

    aiSearchName: aiDependencies.outputs.aiSearchName
    aiSearchServiceResourceGroupName: aiDependencies.outputs.aiSearchServiceResourceGroupName
    aiSearchServiceSubscriptionId: aiDependencies.outputs.aiSearchServiceSubscriptionId

    cosmosDBName: aiDependencies.outputs.cosmosDBName
    cosmosDBSubscriptionId: aiDependencies.outputs.cosmosDBSubscriptionId
    cosmosDBResourceGroupName: aiDependencies.outputs.cosmosDBResourceGroupName

    azureStorageName: aiDependencies.outputs.azureStorageName
    azureStorageSubscriptionId: aiDependencies.outputs.azureStorageSubscriptionId
    azureStorageResourceGroupName: aiDependencies.outputs.azureStorageResourceGroupName
    // dependent resources
    accountName: aiAccount.outputs.accountName
  }
  dependsOn: [
    privateEndpointAndDNS
  ]
}

module formatProjectWorkspaceId 'modules-network-secured/format-project-workspace-id.bicep' = {
  name: 'format-project-workspace-id-${uniqueSuffix}-deployment'
  params: {
    projectWorkspaceId: aiProject.outputs.projectWorkspaceId
  }
}

/*
  Assigns the project SMI the storage blob data contributor role on the storage account
*/
module storageAccountRoleAssignment 'modules-network-secured/azure-storage-account-role-assignment.bicep' = {
  name: 'storage-ra-${uniqueSuffix}-deployment'
  scope: resourceGroup(azureStorageSubscriptionId, azureStorageResourceGroupName)
  params: {
    azureStorageName: aiDependencies.outputs.azureStorageName
    projectPrincipalId: aiProject.outputs.projectPrincipalId
  }
  dependsOn: [
    privateEndpointAndDNS
  ]
}

// The Comos DB Operator role must be assigned before the caphost is created
module cosmosAccountRoleAssignments 'modules-network-secured/cosmosdb-account-role-assignment.bicep' = {
  name: 'cosmos-account-ra-${uniqueSuffix}-deployment'
  scope: resourceGroup(cosmosDBSubscriptionId, cosmosDBResourceGroupName)
  params: {
    cosmosDBName: aiDependencies.outputs.cosmosDBName
    projectPrincipalId: aiProject.outputs.projectPrincipalId
  }
  dependsOn: [
    privateEndpointAndDNS
  ]
}

// This role can be assigned before or after the caphost is created
module aiSearchRoleAssignments 'modules-network-secured/ai-search-role-assignments.bicep' = {
  name: 'ai-search-ra-${uniqueSuffix}-deployment'
  scope: resourceGroup(aiSearchServiceSubscriptionId, aiSearchServiceResourceGroupName)
  params: {
    aiSearchName: aiDependencies.outputs.aiSearchName
    projectPrincipalId: aiProject.outputs.projectPrincipalId
  }
  dependsOn: [
    privateEndpointAndDNS
  ]
}

// This module creates the capability host for the project and account
module addProjectCapabilityHost 'modules-network-secured/add-project-capability-host.bicep' = {
  name: 'capabilityHost-configuration-${uniqueSuffix}-deployment'
  params: {
    accountName: aiAccount.outputs.accountName
    projectName: aiProject.outputs.projectName
    cosmosDBConnection: aiProject.outputs.cosmosDBConnection
    azureStorageConnection: aiProject.outputs.azureStorageConnection
    aiSearchConnection: aiProject.outputs.aiSearchConnection
    projectCapHost: projectCapHost
  }
  dependsOn: [
    privateEndpointAndDNS
    cosmosAccountRoleAssignments
    storageAccountRoleAssignment
    aiSearchRoleAssignments
  ]
}

// The Storage Blob Data Owner role must be assigned after the caphost is created
module storageContainersRoleAssignment 'modules-network-secured/blob-storage-container-role-assignments.bicep' = {
  name: 'storage-containers-ra-${uniqueSuffix}-deployment'
  scope: resourceGroup(azureStorageSubscriptionId, azureStorageResourceGroupName)
  params: {
    aiProjectPrincipalId: aiProject.outputs.projectPrincipalId
    storageName: aiDependencies.outputs.azureStorageName
    workspaceId: formatProjectWorkspaceId.outputs.projectWorkspaceIdGuid
  }
  dependsOn: [
    addProjectCapabilityHost
    storageAccountRoleAssignment
  ]
}

// The Cosmos Built-In Data Contributor role must be assigned after the caphost is created
module cosmosContainerRoleAssignments 'modules-network-secured/cosmos-container-role-assignments.bicep' = {
  name: 'cosmos-containers-ra-${uniqueSuffix}-deployment'
  scope: resourceGroup(cosmosDBSubscriptionId, cosmosDBResourceGroupName)
  params: {
    cosmosAccountName: aiDependencies.outputs.cosmosDBName
    projectWorkspaceId: formatProjectWorkspaceId.outputs.projectWorkspaceIdGuid
    projectPrincipalId: aiProject.outputs.projectPrincipalId
  }
  dependsOn: [
    addProjectCapabilityHost
    storageContainersRoleAssignment
  ]
}

// Grant the project managed identity read access on the tracing Application Insights (for evaluation)
module applicationInsightsRoleAssignment 'modules-network-secured/application-insights-role-assignment.bicep' = {
  name: 'app-insights-ra-${uniqueSuffix}-deployment'
  params: {
    appInsightsName: applicationInsights.outputs.appInsightsName
    projectPrincipalId: aiProject.outputs.projectPrincipalId
  }
}
